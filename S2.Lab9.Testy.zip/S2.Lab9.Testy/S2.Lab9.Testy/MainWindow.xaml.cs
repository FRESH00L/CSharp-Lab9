﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace S2.Lab9.Testy
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        public static (double,double,double) MinimalicujFunkcje(int liczbaIteracji, double minX, double minY, double maxX, double maxY, Func<double,double,double> func)
        {
            object semafor = new object();
            double? najlepszyX = null;
            double? najlepszyY = null;
            double? najlepszaWart = null;
            Random rand = new Random();
            //for(int i =1; i<=liczbaIteracji; i++)
            ParallelOptions po = new ParallelOptions()
            {
                MaxDegreeOfParallelism = 5
            };
            Parallel.For(0, liczbaIteracji, po, i =>
            {
                double x = rand.NextDouble() * (maxX - minX) + minX;
                double y = rand.NextDouble() * (maxY - minY) + minY;
                double wart = func(x, y);
                lock (semafor)
                {
                    if (najlepszaWart == null || najlepszaWart > wart)
                    {
                        najlepszyX = x;
                        najlepszyY = y;
                        najlepszaWart = wart;
                    }
                }

            });
            return ((double)najlepszyX, (double)najlepszyY, (double)najlepszaWart);
        }

        private void btn_Show_Click(object sender, RoutedEventArgs e)
        {
            MinimalicujFunkcje(1000000000, -10, 10, -10, 10, (x, y) => Math.Sin(x) + Math.Cos(y));
        }
    }
}